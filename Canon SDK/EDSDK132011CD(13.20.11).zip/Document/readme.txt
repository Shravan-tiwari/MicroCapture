-----------------------------------------------------------------------------------
                           	EDSDK Library
                                 README File
-----------------------------------------------------------------------------------
This Readme file contains the latest information about the EDSDK Library.
Please read this file before using the EDSDK Library.
-----------------------------------------------------------------------------------


Contents

1. Acknowledgments
2. Copyrights



1. Acknowledgments
------------------

This software is based in part on the work of the Independent JPEG Group.


2. Copyrights
-------------

IJG:

Permission is hereby granted to use, copy, modify, and distribute this 
software (or portions thereof) for any purpose, without fee, subject to 
these conditions:

1. If any part of the source code for this software is distributed, then 
this README file must be included, with this copyright and no-warranty 
notice unaltered; and any additions, deletions, or changes to the original 
files must be clearly indicated in accompanying documentation.

2. If only executable code is distributed, then the accompanying 
documentation must state that "this software is based in part on the work of 
the Independent JPEG Group".

3. Permission for use of this software is granted only if the user accepts 
full responsibility for any undesirable consequences; the authors accept NO 
LIABILITY for damages of any kind.

These conditions apply to any software derived from or based on the IJG 
code, not just to the unmodified library. If you use our work, you ought to 
acknowledge us.

Permission is NOT granted for the use of any IJG author's name or company 
name in advertising or publicity relating to this software or products 
derived from it. This software may be referred to only as "the Independent 
JPEG Group's software".
We specifically permit and encourage the use of this software as the basis 
of commercial products, provided that all warranty or liability claims are 
assumed by the product vendor.

<EN><EOF>